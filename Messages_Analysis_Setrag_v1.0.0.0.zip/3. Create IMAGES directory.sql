CREATE DIRECTORY IMAGES as '(fill in path to directory)';
